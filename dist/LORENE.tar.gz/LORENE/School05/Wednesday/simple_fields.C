// Lorene headers
#include "metric.h"
#include "nbr_spx.h"
#include "utilitaires.h"
#include "graphique.h"

int main() {

    cout << "All is to be done !" << endl ;

    return EXIT_SUCCESS ; 
}
