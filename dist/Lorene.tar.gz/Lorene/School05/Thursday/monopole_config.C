#include "scalar.h"
#include "monopole.h"
#include "param_elliptic.h"
#include "graphique.h"

int Monopole::solve_config(double precis, int itemax, double relax) {
    cout << "Monopole::solve_config is not implemented..." << endl ;
    return 0 ;
}
